
package com.example.inventory;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.inventory.model.InventoryItem;
import com.example.inventory.repository.InventoryRepository;

@SpringBootApplication
public class InventoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(InventoryApplication.class, args);
    }

    @Bean
    CommandLineRunner initData(InventoryRepository repo) {
        return args -> {
            repo.save(new InventoryItem(null, "Laptop", "Electronics", 10, 50000.0));
            repo.save(new InventoryItem(null, "Mouse", "Accessories", 150, 450.0));
            repo.save(new InventoryItem(null, "Keyboard", "Accessories", 80, 850.0));
        };
    }
}
