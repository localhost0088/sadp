
package com.example.inventory.controller;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.inventory.model.InventoryItem;
import com.example.inventory.service.InventoryService;

@RestController
@RequestMapping("/api/inventory")
public class InventoryRestController {
    private final InventoryService service;
    public InventoryRestController(InventoryService service) { this.service = service; }

    @GetMapping
    public List<InventoryItem> list() { return service.listAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<InventoryItem> get(@PathVariable Long id) {
        InventoryItem item = service.get(id);
        if (item == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(item);
    }

    @PostMapping
    public InventoryItem create(@RequestBody InventoryItem item) { return service.save(item); }

    @PutMapping("/{id}")
    public ResponseEntity<InventoryItem> update(@PathVariable Long id, @RequestBody InventoryItem item) {
        InventoryItem existing = service.get(id);
        if (existing == null) return ResponseEntity.notFound().build();
        item.setId(id);
        return ResponseEntity.ok(service.save(item));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        InventoryItem existing = service.get(id);
        if (existing == null) return ResponseEntity.notFound().build();
        service.delete(id);
        return ResponseEntity.ok().build();
    }
}
