
package com.example.inventory.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.example.inventory.model.InventoryItem;
import com.example.inventory.repository.InventoryRepository;

@Service
public class InventoryService {
    private final InventoryRepository repo;
    public InventoryService(InventoryRepository repo) { this.repo = repo; }

    public List<InventoryItem> listAll() { return repo.findAll(); }
    public InventoryItem get(Long id) { return repo.findById(id).orElse(null); }
    public InventoryItem save(InventoryItem item) { return repo.save(item); }
    public void delete(Long id) { repo.deleteById(id); }
}
