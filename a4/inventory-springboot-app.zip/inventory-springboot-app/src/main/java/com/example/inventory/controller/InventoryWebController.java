
package com.example.inventory.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import com.example.inventory.model.InventoryItem;
import com.example.inventory.service.InventoryService;

@Controller
@RequestMapping("/inventory")
public class InventoryWebController {
    private final InventoryService service;
    public InventoryWebController(InventoryService service) { this.service = service; }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("items", service.listAll());
        return "inventory/list";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("inventoryItem", new InventoryItem());
        return "inventory/form";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("inventoryItem") InventoryItem item, BindingResult br, Model model) {
        if (br.hasErrors()) {
            return "inventory/form";
        }
        service.save(item);
        return "redirect:/inventory";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        InventoryItem item = service.get(id);
        if (item == null) return "redirect:/inventory";
        model.addAttribute("inventoryItem", item);
        return "inventory/form";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.delete(id);
        return "redirect:/inventory";
    }
}
