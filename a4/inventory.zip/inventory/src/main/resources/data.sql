CREATE TABLE items (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    quantity INT,
    price DOUBLE
);

INSERT INTO items (name, quantity, price) VALUES ('Laptop', 10, 75000.0);
INSERT INTO items (name, quantity, price) VALUES ('Phone', 20, 25000.0);
INSERT INTO items (name, quantity, price) VALUES ('Tablet', 15, 15000.0);
