package com.example.hr.service;
import com.example.hr.entity.UserEntity;
import com.example.hr.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service @Transactional
public class UserService {
    private final UserRepository repo;
    public UserService(UserRepository repo){this.repo=repo;}
    public List<UserEntity> findAll(){return repo.findAll();}
    public UserEntity get(Long id){return repo.findById(id).orElseThrow();}
    public UserEntity create(UserEntity u){return repo.save(u);}
    public UserEntity update(Long id, UserEntity u){UserEntity ex = get(id); ex.setName(u.getName()); ex.setEmail(u.getEmail()); return repo.save(ex);}
    public void delete(Long id){repo.deleteById(id);}
}
