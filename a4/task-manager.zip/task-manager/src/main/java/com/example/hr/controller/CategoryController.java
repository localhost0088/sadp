package com.example.hr.controller;
import com.example.hr.dto.CategoryDTO;
import com.example.hr.entity.Category;
import com.example.hr.service.CategoryService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
    private final CategoryService service;
    public CategoryController(CategoryService service){this.service=service;}

    @GetMapping public List<CategoryDTO> all(){ return service.findAll().stream().map(c->new CategoryDTO(c.getId(), c.getName(), c.getDescription())).collect(Collectors.toList()); }
    @GetMapping("/{id}") public CategoryDTO get(@PathVariable Long id){ Category c = service.get(id); return new CategoryDTO(c.getId(), c.getName(), c.getDescription()); }
    @PostMapping @ResponseStatus(HttpStatus.CREATED) public CategoryDTO create(@Valid @RequestBody CategoryDTO dto){ Category c = service.create(new Category(dto.getName(), dto.getDescription())); dto.setId(c.getId()); return dto; }
    @PutMapping("/{id}") public CategoryDTO update(@PathVariable Long id, @Valid @RequestBody CategoryDTO dto){ Category c = new Category(dto.getName(), dto.getDescription()); Category saved = service.update(id, c); return new CategoryDTO(saved.getId(), saved.getName(), saved.getDescription()); }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable Long id){ service.delete(id); }
}
