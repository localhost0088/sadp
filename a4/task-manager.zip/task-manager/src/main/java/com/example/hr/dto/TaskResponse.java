package com.example.hr.dto;
import java.time.LocalDate;
import com.example.hr.entity.TaskStatus;
public class TaskResponse {
    private Long id; private String title; private String description; private Long categoryId; private String categoryName;
    private Long assigneeId; private String assigneeName; private LocalDate dueDate; private TaskStatus status;
    public TaskResponse() {}
    public TaskResponse(Long id, String title, String description, Long categoryId, String categoryName, Long assigneeId, String assigneeName, LocalDate dueDate, TaskStatus status){
        this.id=id;this.title=title;this.description=description;this.categoryId=categoryId;this.categoryName=categoryName;this.assigneeId=assigneeId;this.assigneeName=assigneeName;this.dueDate=dueDate;this.status=status;
    }
    // getters/setters
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getTitle(){return title;} public void setTitle(String t){this.title=t;}
    public String getDescription(){return description;} public void setDescription(String d){this.description=d;}
    public Long getCategoryId(){return categoryId;} public void setCategoryId(Long id){this.categoryId=id;}
    public String getCategoryName(){return categoryName;} public void setCategoryName(String n){this.categoryName=n;}
    public Long getAssigneeId(){return assigneeId;} public void setAssigneeId(Long id){this.assigneeId=id;}
    public String getAssigneeName(){return assigneeName;} public void setAssigneeName(String n){this.assigneeName=n;}
    public LocalDate getDueDate(){return dueDate;} public void setDueDate(LocalDate d){this.dueDate=d;}
    public TaskStatus getStatus(){return status;} public void setStatus(TaskStatus s){this.status=s;}
}
