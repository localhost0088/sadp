package com.example.hr.controller;
import com.example.hr.entity.UserEntity;
import com.example.hr.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserService service;
    public UserController(UserService service){this.service=service;}

    @GetMapping
    public List<com.example.hr.dto.UserDTO> all(){
        return service.findAll().stream()
            .map(u -> new com.example.hr.dto.UserDTO(u.getId(), u.getName(), u.getEmail()))
            .toList();
    }

    @GetMapping("/{id}")
    public com.example.hr.dto.UserDTO get(@PathVariable Long id){
        UserEntity u = service.get(id);
        return new com.example.hr.dto.UserDTO(u.getId(), u.getName(), u.getEmail());
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public com.example.hr.dto.UserDTO create(@Valid @RequestBody com.example.hr.dto.UserDTO dto){
        UserEntity u = new UserEntity(dto.getName(), dto.getEmail());
        UserEntity saved = service.create(u);
        dto.setId(saved.getId());
        return dto;
    }

    @PutMapping("/{id}")
    public com.example.hr.dto.UserDTO update(@PathVariable Long id, @Valid @RequestBody com.example.hr.dto.UserDTO dto){
        UserEntity u = new UserEntity(dto.getName(), dto.getEmail());
        UserEntity saved = service.update(id, u);
        return new com.example.hr.dto.UserDTO(saved.getId(), saved.getName(), saved.getEmail());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id){service.delete(id);}
}
