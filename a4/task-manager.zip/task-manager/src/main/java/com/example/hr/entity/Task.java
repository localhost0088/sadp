package com.example.hr.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "tasks")
public class Task {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false) private String title;
    @Column(length = 1000) private String description;

    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "category_id")
    private Category category;

    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "user_id")
    private UserEntity assignee;

    private LocalDate dueDate;

    @Enumerated(EnumType.STRING) private TaskStatus status = TaskStatus.OPEN;

    public Task(){}
    // getters/setters
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getTitle(){return title;} public void setTitle(String title){this.title=title;}
    public String getDescription(){return description;} public void setDescription(String description){this.description=description;}
    public Category getCategory(){return category;} public void setCategory(Category category){this.category=category;}
    public UserEntity getAssignee(){return assignee;} public void setAssignee(UserEntity assignee){this.assignee=assignee;}
    public java.time.LocalDate getDueDate(){return dueDate;} public void setDueDate(java.time.LocalDate dueDate){this.dueDate=dueDate;}
    public TaskStatus getStatus(){return status;} public void setStatus(TaskStatus status){this.status=status;}
}
