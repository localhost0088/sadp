package com.example.hr.service;
import com.example.hr.entity.Category;
import com.example.hr.repository.CategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service @Transactional
public class CategoryService {
    private final CategoryRepository repo;
    public CategoryService(CategoryRepository repo){this.repo=repo;}
    public List<Category> findAll(){return repo.findAll();}
    public Category get(Long id){return repo.findById(id).orElseThrow();}
    public Category create(Category c){return repo.save(c);}
    public Category update(Long id, Category c){Category ex=get(id); ex.setName(c.getName()); ex.setDescription(c.getDescription()); return repo.save(ex);}
    public void delete(Long id){repo.deleteById(id);}
}
