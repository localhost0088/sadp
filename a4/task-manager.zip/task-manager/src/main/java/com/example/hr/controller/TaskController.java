package com.example.hr.controller;
import com.example.hr.dto.TaskCreateRequest;
import com.example.hr.dto.TaskResponse;
import com.example.hr.dto.TaskUpdateRequest;
import com.example.hr.entity.TaskStatus;
import com.example.hr.service.TaskService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {
    private final TaskService service;
    public TaskController(TaskService service){this.service=service;}

    @GetMapping
    public Page<TaskResponse> list(@RequestParam(value = "q", required = false) String q,
                                   @RequestParam(value = "status", required = false) TaskStatus status,
                                   @RequestParam(value = "fromDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
                                   @RequestParam(value = "toDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
                                   Pageable pageable) {
        return service.search(q, status, fromDate, toDate, pageable);
    }

    @GetMapping("/{id}") public TaskResponse get(@PathVariable Long id){return service.get(id);}

    @PostMapping public TaskResponse create(@Valid @RequestBody TaskCreateRequest req){ return service.create(req); }

    @PutMapping("/{id}") public TaskResponse update(@PathVariable Long id, @Valid @RequestBody TaskUpdateRequest req){ return service.update(id, req); }

    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ service.delete(id); }
}
