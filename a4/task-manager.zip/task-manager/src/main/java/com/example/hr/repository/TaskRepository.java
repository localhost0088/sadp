package com.example.hr.repository;
import com.example.hr.entity.Task;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;

public interface TaskRepository extends JpaRepository<Task, Long> {
    @Query("select t from Task t left join t.category c left join t.assignee u " +
           "where (:q is null or lower(t.title) like lower(concat('%',:q,'%')) or lower(t.description) like lower(concat('%',:q,'%')) " +
           "or lower(c.name) like lower(concat('%',:q,'%')) or lower(u.name) like lower(concat('%',:q,'%'))) " +
           "and (:status is null or t.status = :status) " +
           "and (:fromDate is null or t.dueDate >= :fromDate) and (:toDate is null or t.dueDate <= :toDate)")
    Page<Task> search(@Param("q") String q, @Param("status") com.example.hr.entity.TaskStatus status,
                      @Param("fromDate") LocalDate fromDate, @Param("toDate") LocalDate toDate, Pageable pageable);
}
