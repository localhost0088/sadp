package com.example.hr.dto;
import com.example.hr.entity.TaskStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public class TaskUpdateRequest {
    @NotBlank private String title;
    private String description;
    @NotNull private Long categoryId;
    private Long assigneeId;
    private LocalDate dueDate;
    @NotNull private TaskStatus status;
    public String getTitle(){return title;} public void setTitle(String t){this.title=t;}
    public String getDescription(){return description;} public void setDescription(String d){this.description=d;}
    public Long getCategoryId(){return categoryId;} public void setCategoryId(Long id){this.categoryId=id;}
    public Long getAssigneeId(){return assigneeId;} public void setAssigneeId(Long id){this.assigneeId=id;}
    public LocalDate getDueDate(){return dueDate;} public void setDueDate(LocalDate d){this.dueDate=d;}
    public TaskStatus getStatus(){return status;} public void setStatus(TaskStatus s){this.status=s;}
}
