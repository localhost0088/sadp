package com.example.hr.entity;
public enum TaskStatus { OPEN, IN_PROGRESS, DONE }
