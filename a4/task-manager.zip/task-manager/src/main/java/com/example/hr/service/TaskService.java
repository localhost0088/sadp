package com.example.hr.service;
import com.example.hr.dto.TaskCreateRequest;
import com.example.hr.dto.TaskResponse;
import com.example.hr.dto.TaskUpdateRequest;
import com.example.hr.entity.Category;
import com.example.hr.entity.Task;
import com.example.hr.entity.TaskStatus;
import com.example.hr.entity.UserEntity;
import com.example.hr.repository.TaskRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;

@Service @Transactional
public class TaskService {
    private final TaskRepository repo;
    private final CategoryService categoryService;
    private final UserService userService;

    public TaskService(TaskRepository repo, CategoryService categoryService, UserService userService){
        this.repo=repo; this.categoryService=categoryService; this.userService=userService;
    }

    public Page<TaskResponse> search(String q, TaskStatus status, LocalDate fromDate, LocalDate toDate, Pageable pageable){
        return repo.search(q, status, fromDate, toDate, pageable).map(this::toResponse);
    }

    public TaskResponse get(Long id){return toResponse(repo.findById(id).orElseThrow());}

    public TaskResponse create(TaskCreateRequest req){
        Category c = categoryService.get(req.getCategoryId());
        UserEntity u = req.getAssigneeId() != null ? userService.get(req.getAssigneeId()) : null;
        Task t = new Task();
        t.setTitle(req.getTitle()); t.setDescription(req.getDescription()); t.setCategory(c); t.setAssignee(u); t.setDueDate(req.getDueDate());
        Task saved = repo.save(t);
        return toResponse(saved);
    }

    public TaskResponse update(Long id, TaskUpdateRequest req){
        Task t = repo.findById(id).orElseThrow();
        Category c = categoryService.get(req.getCategoryId());
        UserEntity u = req.getAssigneeId() != null ? userService.get(req.getAssigneeId()) : null;
        t.setTitle(req.getTitle()); t.setDescription(req.getDescription()); t.setCategory(c); t.setAssignee(u); t.setDueDate(req.getDueDate()); t.setStatus(req.getStatus());
        return toResponse(repo.save(t));
    }

    public void delete(Long id){repo.deleteById(id);}

    private TaskResponse toResponse(Task t){
        Long catId = t.getCategory() != null ? t.getCategory().getId() : null;
        String catName = t.getCategory() != null ? t.getCategory().getName() : null;
        Long assigneeId = t.getAssignee() != null ? t.getAssignee().getId() : null;
        String assigneeName = t.getAssignee() != null ? t.getAssignee().getName() : null;
        return new TaskResponse(t.getId(), t.getTitle(), t.getDescription(), catId, catName, assigneeId, assigneeName, t.getDueDate(), t.getStatus());
    }
}
