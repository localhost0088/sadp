INSERT INTO users (name, email) VALUES ('Alice', 'alice@example.com'), ('Bob', 'bob@example.com');

INSERT INTO categories (name, description) VALUES ('Bug', 'Bugs & issues'), ('Feature', 'New features'), ('Chore', 'Maintenance');

INSERT INTO tasks (title, description, category_id, user_id, due_date, status) VALUES
  ('Fix login', 'Users cannot login under heavy load', 1, 1, DATE '2025-10-10', 'OPEN'),
  ('Add reports', 'Add monthly reports page', 2, 2, DATE '2025-10-15', 'IN_PROGRESS'),
  ('Cleanup logs', 'Rotate and archive logs', 3, null, DATE '2025-11-01', 'OPEN');
