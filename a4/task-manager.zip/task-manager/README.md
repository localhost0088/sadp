Task Manager (Spring Boot + H2)
-------------------------------
Run:
  mvn spring-boot:run
API endpoints:
  GET  /api/tasks
  GET  /api/tasks/{id}
  POST /api/tasks
  PUT  /api/tasks/{id}
  DELETE /api/tasks/{id}
  GET  /api/categories
  POST /api/categories
  GET  /api/users
  POST /api/users
H2 Console: http://localhost:8080/h2-console  (JDBC URL: jdbc:h2:mem:taskdb, user: sa)
