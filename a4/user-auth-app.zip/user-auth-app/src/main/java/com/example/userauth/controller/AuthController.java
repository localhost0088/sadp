package com.example.userauth.controller;

import com.example.userauth.entity.User;
import com.example.userauth.service.UserService;
import com.example.userauth.exception.InvalidCredentialsException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
        public String register(User user, Model model) {
            // Input validation
            if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
                model.addAttribute("error", "Username is required.");
                return "register";
            }
            if (user.getPassword() == null || user.getPassword().length() < 6) {
                model.addAttribute("error", "Password must be at least 6 characters long.");
                return "register";
            }
            userService.register(user);
            model.addAttribute("message", "User registered successfully!");
            return "login";
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
        public String login(@RequestParam String email, @RequestParam String password, Model model) {
            // Input validation
            if (email == null || email.trim().isEmpty()) {
                model.addAttribute("error", "Email is required.");
                return "login";
            }
            if (password == null || password.length() < 6) {
                model.addAttribute("error", "Password must be at least 6 characters long.");
                return "login";
            }
            try {
                User user = userService.login(email, password);
                model.addAttribute("username", user.getUsername());
                return "home";
            } catch (InvalidCredentialsException e) {
                model.addAttribute("error", e.getMessage());
                return "login";
            }
    }
}
