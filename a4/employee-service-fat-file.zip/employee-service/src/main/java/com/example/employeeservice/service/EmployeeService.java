package com.example.employeeservice.service;

import com.example.employeeservice.model.Employee;
import org.springframework.stereotype.Service;
import java.io.*;
import java.util.*;

@Service
public class EmployeeService {
    private static final String FILE_NAME = "employees.txt";

    public void saveEmployee(Employee emp) {
        try (FileWriter fw = new FileWriter(FILE_NAME, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(emp.getEno() + "," + emp.getEname() + "," + emp.getDesignation() + "," +
                        emp.getDeptName() + "," + emp.getSalary());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    Employee emp = new Employee(
                            Integer.parseInt(parts[0]),
                            parts[1],
                            parts[2],
                            parts[3],
                            Double.parseDouble(parts[4])
                    );
                    employees.add(emp);
                }
            }
        } catch (IOException e) {
            // ignore if file doesn't exist
        }
        return employees;
    }
}
