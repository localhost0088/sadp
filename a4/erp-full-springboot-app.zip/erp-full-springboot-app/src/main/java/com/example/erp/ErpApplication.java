package com.example.erp;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.erp.model.InventoryItem;
import com.example.erp.model.Sale;
import com.example.erp.model.FinancialRecord;
import com.example.erp.repository.InventoryRepository;
import com.example.erp.repository.SalesRepository;
import com.example.erp.repository.FinancialRepository;

import java.math.BigDecimal;
import java.time.LocalDate;

@SpringBootApplication
public class ErpApplication {
    public static void main(String[] args) {
        SpringApplication.run(ErpApplication.class, args);
    }

    @Bean
    CommandLineRunner initData(InventoryRepository inventoryRepo, SalesRepository salesRepo, FinancialRepository financialRepo) {
        return args -> {
            inventoryRepo.save(new InventoryItem(null, "Laptop", "Electronics", 10, new BigDecimal("50000")));
            inventoryRepo.save(new InventoryItem(null, "Mouse", "Accessories", 100, new BigDecimal("500")));
            inventoryRepo.save(new InventoryItem(null, "Keyboard", "Accessories", 60, new BigDecimal("800")));

            Sale s1 = new Sale();
            s1.setProductName("Laptop");
            s1.setQuantity(2);
            s1.setUnitPrice(new BigDecimal("50000"));
            s1.setDate(LocalDate.now().minusDays(2));
            salesRepo.save(s1);

            Sale s2 = new Sale();
            s2.setProductName("Mouse");
            s2.setQuantity(5);
            s2.setUnitPrice(new BigDecimal("500"));
            s2.setDate(LocalDate.now().minusDays(1));
            salesRepo.save(s2);

            financialRepo.save(new FinancialRecord(null, LocalDate.now().minusDays(10), "Office Rent", new BigDecimal("15000"), "EXPENSE"));
            financialRepo.save(new FinancialRecord(null, LocalDate.now().minusDays(3), "Product Sale Income", new BigDecimal("101000"), "INCOME"));
        };
    }
}