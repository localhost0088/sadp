package com.example.erp.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.erp.model.FinancialRecord;
import com.example.erp.repository.FinancialRepository;
import java.util.List;

@RestController
@RequestMapping("/api/financials")
public class FinancialController {
    private final FinancialRepository repo;
    public FinancialController(FinancialRepository repo) { this.repo = repo; }

    @GetMapping public List<FinancialRecord> list() { return repo.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<FinancialRecord> get(@PathVariable Long id) {
        return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping public FinancialRecord create(@RequestBody FinancialRecord rec) { return repo.save(rec); }
    @PutMapping("/{id}") public ResponseEntity<FinancialRecord> update(@PathVariable Long id, @RequestBody FinancialRecord rec) {
        return repo.findById(id).map(existing -> {
            existing.setDate(rec.getDate());
            existing.setDescription(rec.getDescription());
            existing.setAmount(rec.getAmount());
            existing.setType(rec.getType());
            repo.save(existing);
            return ResponseEntity.ok(existing);
        }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id) {
        return repo.findById(id).map(existing -> { repo.delete(existing); return ResponseEntity.ok().<Void>build(); }).orElse(ResponseEntity.notFound().build());
    }
}