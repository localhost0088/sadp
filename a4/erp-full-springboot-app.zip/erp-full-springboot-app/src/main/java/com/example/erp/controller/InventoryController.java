package com.example.erp.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.erp.model.InventoryItem;
import com.example.erp.repository.InventoryRepository;
import java.util.List;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {
    private final InventoryRepository repo;
    public InventoryController(InventoryRepository repo) { this.repo = repo; }

    @GetMapping public List<InventoryItem> list() { return repo.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<InventoryItem> get(@PathVariable Long id) {
        return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping public InventoryItem create(@RequestBody InventoryItem item) { return repo.save(item); }
    @PutMapping("/{id}") public ResponseEntity<InventoryItem> update(@PathVariable Long id, @RequestBody InventoryItem item) {
        return repo.findById(id).map(existing -> {
            existing.setName(item.getName());
            existing.setCategory(item.getCategory());
            existing.setQuantity(item.getQuantity());
            existing.setUnitPrice(item.getUnitPrice());
            repo.save(existing);
            return ResponseEntity.ok(existing);
        }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id) {
        return repo.findById(id).map(existing -> { repo.delete(existing); return ResponseEntity.ok().<Void>build(); }).orElse(ResponseEntity.notFound().build());
    }
}