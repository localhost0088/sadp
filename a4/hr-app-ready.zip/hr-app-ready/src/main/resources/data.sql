INSERT INTO departments (name, description, created_at, updated_at) VALUES
  ('Engineering', 'Product development', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
  ('Sales', 'Revenue team', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
  ('HR', 'People operations', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

INSERT INTO employees (first_name, last_name, email, salary, hire_date, status, department_id, created_at, updated_at) VALUES
  ('Rahul', 'Kulkarni', 'rahul.kulkarni@example.com', 85000.00, DATE '2022-09-01', 'ACTIVE', 1, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
  ('Sneha', 'Sharma', 'sneha.sharma@example.com', 92000.00, DATE '2021-06-15', 'ACTIVE', 1, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
  ('Aman', 'Ali', 'aman.ali@example.com', 60000.00, DATE '2023-01-20', 'INACTIVE', 3, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());
