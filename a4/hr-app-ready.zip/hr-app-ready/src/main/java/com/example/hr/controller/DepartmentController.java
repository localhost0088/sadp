package com.example.hr.controller;

import com.example.hr.dto.DepartmentDTO;
import com.example.hr.service.DepartmentService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {

    private final DepartmentService departmentService;

    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public DepartmentDTO create(@Valid @RequestBody DepartmentDTO dto) {
        return departmentService.create(dto);
    }

    @GetMapping
    public List<DepartmentDTO> all() {
        return departmentService.findAll();
    }
}
