package com.example.hr.service;

import com.example.hr.dto.DepartmentDTO;
import com.example.hr.entity.Department;
import com.example.hr.exception.NotFoundException;
import com.example.hr.repository.DepartmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class DepartmentService {

    private final DepartmentRepository departmentRepository;

    public DepartmentService(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    public DepartmentDTO create(DepartmentDTO dto) {
        Department d = new Department(dto.getName(), dto.getDescription());
        Department saved = departmentRepository.save(d);
        dto.setId(saved.getId());
        return dto;
    }

    public List<DepartmentDTO> findAll() {
        return departmentRepository.findAll().stream()
                .map(d -> new DepartmentDTO(d.getId(), d.getName(), d.getDescription()))
                .toList();
    }

    public Department getOrThrow(Long id) {
        return departmentRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Department not found: " + id));
    }
}
