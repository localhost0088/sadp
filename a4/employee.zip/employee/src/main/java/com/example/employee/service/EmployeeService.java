package com.example.employee.service;

import com.example.employee.model.Employee;
import org.springframework.stereotype.Service;
import com.example.employee.util.FileStorageUtil;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeService {

    private final FileStorageUtil fileStorageUtil;

    public EmployeeService(FileStorageUtil fileStorageUtil) {
        this.fileStorageUtil = fileStorageUtil;
    }

    // Add new employee
    public void addEmployee(Employee employee) {
        fileStorageUtil.saveEmployee(employee);
    }

    // Get all employees
    public List<Employee> getAllEmployees() {
        return fileStorageUtil.readEmployees();
    }

    // Update employee by eno
    public boolean updateEmployee(int eno, Employee updated) {
        return fileStorageUtil.updateEmployeeInFile(eno, updated);
    }
}
