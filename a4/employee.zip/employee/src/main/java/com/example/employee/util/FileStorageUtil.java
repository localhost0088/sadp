package com.example.employee.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.employee.model.Employee;

@Component
public class FileStorageUtil {
    private static final String FILE_PATH = "employees.txt";

    // Save employee
    public void saveEmployee(Employee employee) {
        try (FileWriter writer = new FileWriter(FILE_PATH, true)) {
            writer.write(employee.getEno() + "," +
                         employee.getEname() + "," +
                         employee.getDesignation() + "," +
                         employee.getDeptName() + "," +
                         employee.getSalary() + "\n");
        } catch (IOException e) {
            throw new RuntimeException("Error writing to file", e);
        }
    }

    // Read all employees
    public List<Employee> readEmployees() {
        List<Employee> employees = new ArrayList<>();
        File file = new File(FILE_PATH);
        if (!file.exists()) return employees; // empty list if file doesn't exist

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    Employee emp = new Employee(
                        Integer.parseInt(parts[0]),
                        parts[1],
                        parts[2],
                        parts[3],
                        Double.parseDouble(parts[4])
                    );
                    employees.add(emp);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return employees;
    }

    // Update employee in file
    public boolean updateEmployeeInFile(int eno, Employee updated) {
        List<Employee> employees = readEmployees();
        boolean found = false;

        for (Employee e : employees) {
            if (e.getEno() == eno) {
                e.setEname(updated.getEname());
                e.setDesignation(updated.getDesignation());
                e.setDeptName(updated.getDeptName());
                e.setSalary(updated.getSalary());
                found = true;
                break;
            }
        }

        if (found) {
            // rewrite entire file
            try (FileWriter writer = new FileWriter(FILE_PATH)) {
                for (Employee e : employees) {
                    writer.write(e.getEno() + "," +
                                 e.getEname() + "," +
                                 e.getDesignation() + "," +
                                 e.getDeptName() + "," +
                                 e.getSalary() + "\n");
                }
            } catch (IOException e) {
                throw new RuntimeException("Error updating file", e);
            }
        }

        return found;
    }
}
