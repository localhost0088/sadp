package com.example.employee.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.employee.model.Employee;
import com.example.employee.service.EmployeeService;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    // POST: Add employee
    @PostMapping
    public String addEmployee(@RequestBody Employee employee) {
        employeeService.addEmployee(employee);
        return "Employee saved to flat file successfully!";
    }

    // GET: Get all employees
    @GetMapping
public List<Employee> getEmployees() {
    List<Employee> employees = employeeService.getAllEmployees();
    System.out.println("Employees from file: " + employees);
    return employees;
}


    // PUT: Update employee by eno
    @PutMapping("/{eno}")
    public String updateEmployee(@PathVariable int eno, @RequestBody Employee employee) {
        boolean updated = employeeService.updateEmployee(eno, employee);
        if (updated) return "Employee updated successfully!";
        else return "Employee with eno " + eno + " not found!";
    }
}
