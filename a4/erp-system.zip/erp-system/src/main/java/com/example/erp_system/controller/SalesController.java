package com.example.erp_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.erp_system.dto.SaleRequest;
import com.example.erp_system.entity.Sale;
import com.example.erp_system.service.SalesService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/sales")
public class SalesController {
    @Autowired
    private SalesService salesService;

    @GetMapping
    public List<Sale> listAll() { return salesService.listAll(); }

    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody SaleRequest req) {
        try {
            return ResponseEntity.ok(salesService.createSale(req));
        } catch (RuntimeException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }
}