package com.example.erp_system.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_system.entity.Product;
import com.example.erp_system.repository.ProductRepository;

@Service
public class InventoryService {
    @Autowired
    private ProductRepository productRepository;

    public List<Product> listAll() { return productRepository.findAll(); }

    public Product create(Product product) { return productRepository.save(product); }

    public Optional<Product> findById(Long id) { return productRepository.findById(id); }

    public Product update(Long id, Product updated) {
        return productRepository.findById(id).map(p -> {
            p.setName(updated.getName());
            p.setPrice(updated.getPrice());
            p.setQuantity(updated.getQuantity());
            return productRepository.save(p);
        }).orElseThrow(() -> new RuntimeException("Product not found"));
    }

    public void delete(Long id) { productRepository.deleteById(id); }
}