package com.example.erp_system.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_system.dto.TransactionRequest;
import com.example.erp_system.entity.Transaction;
import com.example.erp_system.repository.TransactionRepository;

@Service
public class FinanceService {
    @Autowired
    private TransactionRepository transactionRepository;

    public List<Transaction> listAll() { return transactionRepository.findAll(); }

    public Transaction create(TransactionRequest req) {
        Transaction t = new Transaction(null, LocalDate.now(), req.getType(),
                req.getAmount(), req.getRemarks());
        return transactionRepository.save(t);
    }
}