package com.example.erp_system.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.erp_system.dto.SaleRequest;
import com.example.erp_system.entity.Product;
import com.example.erp_system.entity.Sale;
import com.example.erp_system.repository.ProductRepository;
import com.example.erp_system.repository.SaleRepository;

@Service
public class SalesService {
    @Autowired
    private SaleRepository saleRepository;
    @Autowired
    private ProductRepository productRepository;

    public List<Sale> listAll() { return saleRepository.findAll(); }

    @Transactional
    public Sale createSale(SaleRequest req) {
        Product product = productRepository.findById(req.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        if (product.getQuantity() < req.getQuantity())
            throw new RuntimeException("Insufficient stock");

        product.setQuantity(product.getQuantity() - req.getQuantity());
        productRepository.save(product);

        Sale sale = new Sale(null, LocalDate.now(), req.getQuantity(),
                req.getQuantity() * product.getPrice(), product);

        return saleRepository.save(sale);
    }
}