package com.example.erp_system.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.erp_system.dto.TransactionRequest;
import com.example.erp_system.entity.Transaction;
import com.example.erp_system.service.FinanceService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/finance")
public class FinanceController {
    @Autowired
    private FinanceService financeService;

    @GetMapping
    public List<Transaction> listAll() { return financeService.listAll(); }

    @PostMapping
    public ResponseEntity<Transaction> create(@Valid @RequestBody TransactionRequest req) {
        return ResponseEntity.ok(financeService.create(req));
    }
}