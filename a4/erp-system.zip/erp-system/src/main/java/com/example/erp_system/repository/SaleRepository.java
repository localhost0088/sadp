package com.example.erp_system.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.erp_system.entity.Sale;

@Repository
public interface SaleRepository extends JpaRepository<Sale, Long> {}
