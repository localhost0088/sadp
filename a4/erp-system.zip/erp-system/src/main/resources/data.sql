INSERT INTO products (name, quantity, price) VALUES ('Laptop', 10, 75000);
INSERT INTO products (name, quantity, price) VALUES ('Phone', 20, 25000);
INSERT INTO products (name, quantity, price) VALUES ('Tablet', 15, 15000);

INSERT INTO sales (product_id, quantity, date, total_amount) VALUES (1, 2, CURRENT_DATE(), 200.0);

INSERT INTO transactions (amount, type, date, remarks) VALUES (50000, 'SALE', CURRENT_DATE(), 'Initial sale');
INSERT INTO transactions (amount, type, date, remarks) VALUES (15000, 'PURCHASE', CURRENT_DATE(), 'Initial purchase');
