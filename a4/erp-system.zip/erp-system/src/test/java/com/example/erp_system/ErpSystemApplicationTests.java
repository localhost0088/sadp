package com.example.erp_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErpSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}

