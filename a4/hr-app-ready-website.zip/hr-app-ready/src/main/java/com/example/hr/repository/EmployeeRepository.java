package com.example.hr.repository;

import com.example.hr.entity.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    Optional<Employee> findByEmail(String email);
    boolean existsByEmail(String email);

    @Query("select e from Employee e left join e.department d where lower(e.firstName) like lower(concat('%', :q, '%')) or lower(e.lastName) like lower(concat('%', :q, '%')) or lower(e.email) like lower(concat('%', :q, '%')) or lower(d.name) like lower(concat('%', :q, '%'))")
    Page<Employee> search(@Param("q") String query, Pageable pageable);
}
