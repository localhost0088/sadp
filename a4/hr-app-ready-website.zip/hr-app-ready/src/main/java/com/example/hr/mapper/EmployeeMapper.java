package com.example.hr.mapper;

import com.example.hr.dto.EmployeeResponse;
import com.example.hr.entity.Employee;

public class EmployeeMapper {
    public static EmployeeResponse toResponse(Employee e) {
        Long deptId = e.getDepartment() != null ? e.getDepartment().getId() : null;
        String deptName = e.getDepartment() != null ? e.getDepartment().getName() : null;
        return new EmployeeResponse(
            e.getId(),
            e.getFirstName(),
            e.getLastName(),
            e.getEmail(),
            e.getSalary(),
            e.getHireDate(),
            e.getStatus(),
            deptId,
            deptName,
            e.getCreatedAt(),
            e.getUpdatedAt()
        );
    }
}
