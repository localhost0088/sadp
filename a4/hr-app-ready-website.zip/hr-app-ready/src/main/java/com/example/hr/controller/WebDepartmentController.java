package com.example.hr.controller;

import com.example.hr.dto.DepartmentDTO;
import com.example.hr.service.DepartmentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/departments")
public class WebDepartmentController {

    private final DepartmentService departmentService;

    public WebDepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @GetMapping
    public String listDepartments(Model model) {
        model.addAttribute("departments", departmentService.findAll());
        return "departments/list";
    }

    @GetMapping("/new")
    public String newDepartmentForm(Model model) {
        model.addAttribute("department", new DepartmentDTO());
        return "departments/form";
    }

    @PostMapping
    public String createDepartment(@ModelAttribute DepartmentDTO department) {
        departmentService.save(department);
        return "redirect:/departments";
    }

    @GetMapping("/edit/{id}")
    public String editDepartmentForm(@PathVariable Long id, Model model) {
        model.addAttribute("department", departmentService.findById(id));
        return "departments/form";
    }

    @PostMapping("/edit/{id}")
    public String updateDepartment(@PathVariable Long id, @ModelAttribute DepartmentDTO department) {
        department.setId(id);
        departmentService.save(department);
        return "redirect:/departments";
    }

    @GetMapping("/delete/{id}")
    public String deleteDepartment(@PathVariable Long id, Model model) {
        try {
            departmentService.delete(id);
            return "redirect:/departments";
        } catch (Exception ex) {
            model.addAttribute("departments", departmentService.findAll());
            model.addAttribute("error", ex.getMessage());
            return "departments/list";
        }
    }
}