package com.example.hr.controller;

import com.example.hr.dto.EmployeeCreateRequest;
import com.example.hr.dto.EmployeeResponse;
import com.example.hr.dto.EmployeeUpdateRequest;
import com.example.hr.service.EmployeeService;
import com.example.hr.service.DepartmentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/employees")
public class WebEmployeeController {

    private final EmployeeService employeeService;
    private final DepartmentService departmentService;

    public WebEmployeeController(EmployeeService employeeService, DepartmentService departmentService) {
        this.employeeService = employeeService;
        this.departmentService = departmentService;
    }

    @GetMapping
    public String listEmployees(Model model, @RequestParam(value = "search", required = false) String search) {
        model.addAttribute("employees", employeeService.listAll(search));
        return "employees/list";
    }

    @GetMapping("/new")
    public String newEmployeeForm(Model model) {
        model.addAttribute("employee", new EmployeeCreateRequest());
        model.addAttribute("departments", departmentService.findAll());
        return "employees/form";
    }

    @PostMapping
    public String createEmployee(@RequestParam String firstName,
                                 @RequestParam String lastName,
                                 @RequestParam String email,
                                 @RequestParam java.math.BigDecimal salary,
                                 @RequestParam java.time.LocalDate hireDate,
                                 @RequestParam Long departmentId) {
        EmployeeCreateRequest req = new EmployeeCreateRequest();
        req.setFirstName(firstName);
        req.setLastName(lastName);
        req.setEmail(email);
        req.setSalary(salary);
        req.setHireDate(hireDate);
        req.setDepartmentId(departmentId);
        employeeService.create(req);
        return "redirect:/employees";
    }

    @GetMapping("/edit/{id}")
    public String editEmployeeForm(@PathVariable Long id, Model model) {
        EmployeeResponse employee = employeeService.get(id);
        model.addAttribute("employee", employee);
        model.addAttribute("departments", departmentService.findAll());
        return "employees/form";
    }

    @PostMapping("/edit/{id}")
    public String updateEmployee(@PathVariable Long id,
                                 @RequestParam String firstName,
                                 @RequestParam String lastName,
                                 @RequestParam String email,
                                 @RequestParam java.math.BigDecimal salary,
                                 @RequestParam java.time.LocalDate hireDate,
                                 @RequestParam Long departmentId,
                                 @RequestParam com.example.hr.entity.EmployeeStatus status) {
        EmployeeUpdateRequest req = new EmployeeUpdateRequest();
        req.setFirstName(firstName);
        req.setLastName(lastName);
        req.setEmail(email);
        req.setSalary(salary);
        req.setHireDate(hireDate);
        req.setDepartmentId(departmentId);
        req.setStatus(status);
        employeeService.update(id, req);
        return "redirect:/employees";
    }

    @GetMapping("/delete/{id}")
    public String deleteEmployee(@PathVariable Long id) {
        employeeService.delete(id);
        return "redirect:/employees";
    }
}