package com.example.hr.entity;

public enum EmployeeStatus {
    ACTIVE, INACTIVE
}
