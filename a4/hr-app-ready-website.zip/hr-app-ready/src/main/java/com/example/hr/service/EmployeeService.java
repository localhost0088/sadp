package com.example.hr.service;

import com.example.hr.dto.EmployeeCreateRequest;
import com.example.hr.dto.EmployeeResponse;
import com.example.hr.dto.EmployeeUpdateRequest;
import com.example.hr.entity.Department;
import com.example.hr.entity.Employee;
import com.example.hr.entity.EmployeeStatus;
import com.example.hr.exception.NotFoundException;
import com.example.hr.mapper.EmployeeMapper;
import com.example.hr.repository.DepartmentRepository;
import com.example.hr.repository.EmployeeRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;

    public EmployeeService(EmployeeRepository employeeRepository, DepartmentRepository departmentRepository) {
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
    }

    public Page<EmployeeResponse> list(String search, Pageable pageable) {
        if (search != null && !search.isBlank()) {
            return employeeRepository.search(search.trim(), pageable).map(EmployeeMapper::toResponse);
        }
        return employeeRepository.findAll(pageable).map(EmployeeMapper::toResponse);
    }

        public java.util.List<EmployeeResponse> listAll(String search) {
            if (search != null && !search.isBlank()) {
                return employeeRepository.search(search.trim(), Pageable.unpaged())
                        .map(EmployeeMapper::toResponse)
                        .getContent();
            }
            return employeeRepository.findAll().stream()
                    .map(EmployeeMapper::toResponse)
                    .toList();
        }

    public EmployeeResponse get(Long id) {
        Employee e = employeeRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Employee not found: " + id));
        return EmployeeMapper.toResponse(e);
    }

    public EmployeeResponse create(EmployeeCreateRequest req) {
        if (employeeRepository.existsByEmail(req.getEmail())) {
            throw new DataIntegrityViolationException("Email already exists: " + req.getEmail());
        }
        Department dept = departmentRepository.findById(req.getDepartmentId())
                .orElseThrow(() -> new NotFoundException("Department not found: " + req.getDepartmentId()));
        Employee e = new Employee();
        e.setFirstName(req.getFirstName());
        e.setLastName(req.getLastName());
        e.setEmail(req.getEmail());
        e.setSalary(req.getSalary());
        e.setHireDate(req.getHireDate());
        e.setDepartment(dept);
        e.setStatus(EmployeeStatus.ACTIVE);
        Employee saved = employeeRepository.save(e);
        return EmployeeMapper.toResponse(saved);
    }

    public EmployeeResponse update(Long id, EmployeeUpdateRequest req) {
        Employee e = employeeRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Employee not found: " + id));
        Department dept = departmentRepository.findById(req.getDepartmentId())
                .orElseThrow(() -> new NotFoundException("Department not found: " + req.getDepartmentId()));

        if (!e.getEmail().equals(req.getEmail()) && employeeRepository.existsByEmail(req.getEmail())) {
            throw new DataIntegrityViolationException("Email already exists: " + req.getEmail());
        }

        e.setFirstName(req.getFirstName());
        e.setLastName(req.getLastName());
        e.setEmail(req.getEmail());
        e.setSalary(req.getSalary());
        e.setHireDate(req.getHireDate());
        e.setDepartment(dept);
        e.setStatus(req.getStatus());
        Employee saved = employeeRepository.save(e);
        return EmployeeMapper.toResponse(saved);
    }

    public void delete(Long id) {
        if (!employeeRepository.existsById(id)) {
            throw new NotFoundException("Employee not found: " + id);
        }
        employeeRepository.deleteById(id);
    }
}
