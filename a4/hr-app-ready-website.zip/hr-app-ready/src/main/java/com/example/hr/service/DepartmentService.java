package com.example.hr.service;

import com.example.hr.dto.DepartmentDTO;
import com.example.hr.entity.Department;
import com.example.hr.exception.NotFoundException;
import com.example.hr.repository.DepartmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class DepartmentService {

    private final DepartmentRepository departmentRepository;

    public DepartmentService(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    public DepartmentDTO save(DepartmentDTO dto) {
        Department d = dto.getId() != null ? getOrThrow(dto.getId()) : new Department();
        d.setName(dto.getName());
        d.setDescription(dto.getDescription());
        Department saved = departmentRepository.save(d);
        return new DepartmentDTO(saved.getId(), saved.getName(), saved.getDescription());
    }

    public List<DepartmentDTO> findAll() {
        return departmentRepository.findAll().stream()
                .map(d -> new DepartmentDTO(d.getId(), d.getName(), d.getDescription()))
                .toList();
    }

    public DepartmentDTO findById(Long id) {
        Department department = getOrThrow(id);
        return new DepartmentDTO(department.getId(), department.getName(), department.getDescription());
    }

    public void delete(Long id) {
        if (!departmentRepository.existsById(id)) {
            throw new NotFoundException("Department not found: " + id);
        }
        try {
            departmentRepository.deleteById(id);
        } catch (org.springframework.dao.DataIntegrityViolationException ex) {
            throw new RuntimeException("Cannot delete department: It has employees assigned.");
        }
    }

    private Department getOrThrow(Long id) {
        return departmentRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Department not found: " + id));
    }
}
