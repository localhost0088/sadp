package com.example.taskmanagement.service;

import com.example.taskmanagement.entity.Task;
import com.example.taskmanagement.repository.TaskRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {
    private final TaskRepository taskRepository;

    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public List<Task> list() {
        return taskRepository.findAll();
    }

    public Optional<Task> get(Long id) {
        return taskRepository.findById(id);
    }

    public Task create(Task task) {
        return taskRepository.save(task);
    }

    public Task update(Long id, Task payload) {
        return taskRepository.findById(id).map(task -> {
            task.setTitle(payload.getTitle());
            task.setDescription(payload.getDescription());
            task.setDueDate(payload.getDueDate());
            task.setCompleted(payload.isCompleted());
            task.setCategory(payload.getCategory());
            return taskRepository.save(task);
        }).orElse(null);
    }

    public void delete(Long id) {
        taskRepository.deleteById(id);
    }
}
