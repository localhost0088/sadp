package com.example.hrapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrappApplicationTests {

	@Test
	void contextLoads() {
	}

}
