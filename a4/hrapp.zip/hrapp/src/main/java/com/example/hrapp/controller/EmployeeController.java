package com.example.hrapp.controller;

import com.example.hrapp.dto.EmployeeDto;
import com.example.hrapp.entity.Employee;
import com.example.hrapp.service.EmployeeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    // Convert Entity to DTO
    private EmployeeDto convertToDto(Employee employee) {
        EmployeeDto dto = new EmployeeDto();
        dto.id = employee.getId();
        dto.firstName = employee.getFirstName();
        dto.lastName = employee.getLastName();
        dto.email = employee.getEmail();
        dto.role = employee.getRole();
        if (employee.getDepartment() != null) {
            dto.departmentId = employee.getDepartment().getId();
        }
        return dto;
    }

    @GetMapping
    public List<EmployeeDto> list() {
        return employeeService.list().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<EmployeeDto> get(@PathVariable Long id) {
        Optional<Employee> e = employeeService.get(id);
        return e.map(employee -> ResponseEntity.ok(convertToDto(employee)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<EmployeeDto> create(@RequestBody Employee payload) {
        Employee saved = employeeService.create(payload);
        return ResponseEntity.created(URI.create("/employees/" + saved.getId()))
                .body(convertToDto(saved));
    }
}
