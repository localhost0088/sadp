package com.example.hrapp.dto;


public class EmployeeDto {
public Long id;
public String firstName;
public String lastName;
public String email;
public String role;
public Long departmentId;
}