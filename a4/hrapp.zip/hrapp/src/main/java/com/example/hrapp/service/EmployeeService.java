package com.example.hrapp.service;


import com.example.hrapp.entity.Department;
import com.example.hrapp.entity.Employee;
import com.example.hrapp.repository.DepartmentRepository;
import com.example.hrapp.repository.EmployeeRepository;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Optional;


@Service
public class EmployeeService {
private final EmployeeRepository employeeRepository;
private final DepartmentRepository departmentRepository;


public EmployeeService(EmployeeRepository employeeRepository, DepartmentRepository departmentRepository) {
this.employeeRepository = employeeRepository;
this.departmentRepository = departmentRepository;
}


public Employee create(Employee e) {
if (e.getDepartment() != null && e.getDepartment().getId() != null) {
Optional<Department> d = departmentRepository.findById(e.getDepartment().getId());
d.ifPresent(e::setDepartment);
}
return employeeRepository.save(e);
}


public List<Employee> list() { return employeeRepository.findAll(); }


public Optional<Employee> get(Long id) { return employeeRepository.findById(id); }


public Employee update(Long id, Employee payload) {
return employeeRepository.findById(id).map(e -> {
	e.setFirstName(payload.getFirstName());
	e.setLastName(payload.getLastName());
	e.setEmail(payload.getEmail());
	e.setDepartment(payload.getDepartment());
	return employeeRepository.save(e);
}).orElse(null);
}
}