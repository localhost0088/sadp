INSERT INTO DEPARTMENT (id, name) VALUES (1, 'Engineering');
INSERT INTO DEPARTMENT (id, name) VALUES (2, 'HR');
INSERT INTO EMPLOYEE (id, first_name, last_name, email, role, department_id) VALUES (1, 'Alice', 'Sharma', 'alice@example.com', 'Developer', 1);
INSERT INTO EMPLOYEE (id, first_name, last_name, email, role, department_id) VALUES (2, 'Bob', 'Patil', 'bob@example.com', 'HR Manager', 2);