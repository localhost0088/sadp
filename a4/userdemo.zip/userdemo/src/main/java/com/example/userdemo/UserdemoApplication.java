package com.example.userdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserdemoApplication.class, args);
    }
}


// 1. Register a New User

//     HTTP Method: POST

//     URL: http://localhost:8080/api/auth/register

//     Headers:

//         Content-Type: application/json

//     Body (raw JSON):

// json
// {
//   "username": "testuser",
//   "email": "testuser@example.com",
//   "password": "password123"
// }
//     URL: http://localhost:8080/api/auth/login

//     Headers:

//         Content-Type: application/json

//     Body (raw JSON):

// json
// {
//   "username": "testuser",
//   "password": "password123"
// }
