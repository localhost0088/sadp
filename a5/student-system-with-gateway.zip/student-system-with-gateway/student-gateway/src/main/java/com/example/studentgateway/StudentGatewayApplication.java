package com.example.studentgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentGatewayApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentGatewayApplication.class, args);
    }
}
