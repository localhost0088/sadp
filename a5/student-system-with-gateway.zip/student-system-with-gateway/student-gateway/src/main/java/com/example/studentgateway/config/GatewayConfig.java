package com.example.studentgateway.config;

import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.core.publisher.Mono;

@Configuration
public class GatewayConfig {
    @Bean
    public GlobalFilter logFilter() {
        return (exchange, chain) -> {
            System.out.println("[Gateway] Incoming: " + exchange.getRequest().getURI());
            return chain.filter(exchange)
                        .then(Mono.fromRunnable(() ->
                            System.out.println("[Gateway] Outgoing: " + exchange.getResponse().getStatusCode())
                        ));
        };
    }
}
