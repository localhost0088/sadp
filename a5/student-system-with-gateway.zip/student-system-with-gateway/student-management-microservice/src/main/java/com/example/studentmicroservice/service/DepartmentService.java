package com.example.studentmicroservice.service;

import com.example.studentmicroservice.model.Department;
import com.example.studentmicroservice.repository.DepartmentRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService {
    private final DepartmentRepository repo;

    public DepartmentService(DepartmentRepository repo) { this.repo = repo; }

    public List<Department> getAll() { return repo.findAll(); }
    public Optional<Department> getById(Long id) { return repo.findById(id); }
    public Department save(Department d) { return repo.save(d); }
    public void delete(Long id) { repo.deleteById(id); }
}
