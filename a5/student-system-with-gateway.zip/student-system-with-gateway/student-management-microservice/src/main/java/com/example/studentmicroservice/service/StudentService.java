package com.example.studentmicroservice.service;

import com.example.studentmicroservice.model.Student;
import com.example.studentmicroservice.model.Department;
import com.example.studentmicroservice.repository.StudentRepository;
import com.example.studentmicroservice.repository.DepartmentRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    private final StudentRepository studentRepo;
    private final DepartmentRepository deptRepo;

    public StudentService(StudentRepository studentRepo, DepartmentRepository deptRepo) {
        this.studentRepo = studentRepo;
        this.deptRepo = deptRepo;
    }

    public List<Student> getAll() { return studentRepo.findAll(); }
    public Optional<Student> getById(Long id) { return studentRepo.findById(id); }
    public List<Student> getByDepartment(Long deptId) { return studentRepo.findByDepartmentId(deptId); }

    public Student create(Student s) {
        if (s.getDepartment() != null && s.getDepartment().getId() != null) {
            Department d = deptRepo.findById(s.getDepartment().getId()).orElse(null);
            s.setDepartment(d);
        }
        return studentRepo.save(s);
    }

    public Student update(Long id, Student s) {
        Student existing = studentRepo.findById(id).orElseThrow(() -> new RuntimeException("Student not found"));
        existing.setName(s.getName());
        existing.setEmail(s.getEmail());
        existing.setCourse(s.getCourse());
        if (s.getDepartment() != null && s.getDepartment().getId() != null) {
            Department d = deptRepo.findById(s.getDepartment().getId()).orElse(null);
            existing.setDepartment(d);
        } else {
            existing.setDepartment(null);
        }
        return studentRepo.save(existing);
    }

    public void delete(Long id) { studentRepo.deleteById(id); }
}
