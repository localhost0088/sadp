package com.example.studentmicroservice;

import com.example.studentmicroservice.model.Department;
import com.example.studentmicroservice.model.Student;
import com.example.studentmicroservice.repository.DepartmentRepository;
import com.example.studentmicroservice.repository.StudentRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer {
    private final DepartmentRepository deptRepo;
    private final StudentRepository studentRepo;

    public DataInitializer(DepartmentRepository deptRepo, StudentRepository studentRepo) {
        this.deptRepo = deptRepo;
        this.studentRepo = studentRepo;
    }

    @PostConstruct
    public void init() {
        Department d1 = new Department("Computer Science");
        Department d2 = new Department("Mathematics");
        deptRepo.save(d1);
        deptRepo.save(d2);

        Student s1 = new Student("Alice","alice@example.com","BSc Computer Science");
        s1.setDepartment(d1);
        studentRepo.save(s1);

        Student s2 = new Student("Bob","bob@example.com","BSc Mathematics");
        s2.setDepartment(d2);
        studentRepo.save(s2);
    }
}
