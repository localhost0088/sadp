package com.example.employeedepartment.service;

import com.example.employeedepartment.entity.Employee;
import com.example.employeedepartment.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {
    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Optional<Employee> getEmployee(Long id) {
        return employeeRepository.findById(id);
    }

    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Employee updateEmployee(Long id, Employee emp) {
        return employeeRepository.findById(id).map(existing -> {
            existing.setFirstName(emp.getFirstName());
            existing.setLastName(emp.getLastName());
            existing.setEmail(emp.getEmail());
            existing.setRole(emp.getRole());
            existing.setDepartment(emp.getDepartment());
            return employeeRepository.save(existing);
        }).orElse(null);
    }

    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

    public List<Employee> getEmployeesByDepartment(Long deptId) {
        return employeeRepository.findByDepartmentId(deptId);
    }
}
