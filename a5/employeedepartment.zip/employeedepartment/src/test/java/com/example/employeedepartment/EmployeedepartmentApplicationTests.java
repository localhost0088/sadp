package com.example.employeedepartment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeedepartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
