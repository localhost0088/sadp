package com.example.hrmicroservice.controller;

import com.example.hrmicroservice.model.Candidate;
import com.example.hrmicroservice.model.Notification;
import com.example.hrmicroservice.repository.CandidateRepository;
import com.example.hrmicroservice.service.NotificationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    private final NotificationService service;
    private final CandidateRepository candidateRepository;

    public NotificationController(NotificationService service, CandidateRepository candidateRepository) {
        this.service = service;
        this.candidateRepository = candidateRepository;
    }

    @PostMapping("/send/{candidateId}")
    public ResponseEntity<Notification> sendToCandidate(@PathVariable Long candidateId) {
        Notification n = service.sendSelectionMessageToCandidate(candidateId);
        return ResponseEntity.ok(n);
    }

    @PostMapping("/send")
    public ResponseEntity<Notification> sendDirect(@RequestParam String recipient) {
        Notification n = service.sendSelectionMessageDirect(recipient, "email");
        return ResponseEntity.ok(n);
    }

    @GetMapping
    public List<Notification> all() {
        return service.getAll();
    }

    @PostMapping("/candidate")
    public ResponseEntity<Candidate> createCandidate(@RequestBody Candidate candidate) {
        Candidate saved = candidateRepository.save(candidate);
        return ResponseEntity.ok(saved);
    }
}
