package com.example.hrmicroservice.controller;

import com.example.hrmicroservice.model.Candidate;
import com.example.hrmicroservice.model.Notification;
import com.example.hrmicroservice.repository.CandidateRepository;
import com.example.hrmicroservice.service.NotificationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class WebController {
    private final CandidateRepository candidateRepository;
    private final NotificationService notificationService;

    public WebController(CandidateRepository candidateRepository, NotificationService notificationService) {
        this.candidateRepository = candidateRepository;
        this.notificationService = notificationService;
    }

    @GetMapping({"/", "/candidates"})
    public String candidates(Model model) {
        model.addAttribute("candidates", candidateRepository.findAll());
        return "candidates";
    }

    @GetMapping("/candidates/new")
    public String newCandidateForm(Model model) {
        model.addAttribute("candidate", new Candidate());
        return "candidate_form";
    }

    @PostMapping("/candidates/save")
    public String saveCandidate(@ModelAttribute Candidate candidate, RedirectAttributes ra) {
        candidateRepository.save(candidate);
        ra.addFlashAttribute("success", "Candidate saved");
        return "redirect:/candidates";
    }

    @GetMapping("/notify/{id}")
    public String notifyCandidate(@PathVariable Long id, RedirectAttributes ra) {
        try {
            Notification n = notificationService.sendSelectionMessageToCandidate(id);
            ra.addFlashAttribute("success", "Notification sent to " + n.getRecipient());
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/candidates";
    }

    @GetMapping("/notifications")
    public String notifications(Model model) {
        model.addAttribute("notifications", notificationService.getAll());
        return "notifications";
    }

    @GetMapping("/notify/direct")
    public String directNotifyForm(Model model) {
        return "notify_direct";
    }

    @PostMapping("/notify/direct")
    public String directNotify(@RequestParam String recipient, RedirectAttributes ra) {
        Notification n = notificationService.sendSelectionMessageDirect(recipient, "email");
        ra.addFlashAttribute("success", "Notification sent to " + n.getRecipient());
        return "redirect:/notifications";
    }
}
