package com.example.hrmicroservice.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "notifications")
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String recipient; // email or phone
    private String message;

    private LocalDateTime sentAt;

    public Notification() {}

    public Notification(String recipient, String message, LocalDateTime sentAt) {
        this.recipient = recipient;
        this.message = message;
        this.sentAt = sentAt;
    }

    public Long getId() { return id; }
    public String getRecipient() { return recipient; }
    public void setRecipient(String recipient) { this.recipient = recipient; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public LocalDateTime getSentAt() { return sentAt; }
    public void setSentAt(LocalDateTime sentAt) { this.sentAt = sentAt; }
}
