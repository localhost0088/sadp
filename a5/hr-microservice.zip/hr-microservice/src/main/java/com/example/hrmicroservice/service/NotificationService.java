package com.example.hrmicroservice.service;

import com.example.hrmicroservice.model.Candidate;
import com.example.hrmicroservice.model.Notification;
import com.example.hrmicroservice.repository.CandidateRepository;
import com.example.hrmicroservice.repository.NotificationRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class NotificationService {
    private final NotificationRepository notificationRepository;
    private final CandidateRepository candidateRepository;

    public NotificationService(NotificationRepository notificationRepository, CandidateRepository candidateRepository) {
        this.notificationRepository = notificationRepository;
        this.candidateRepository = candidateRepository;
    }

    public Notification sendSelectionMessageToCandidate(Long candidateId) {
        Optional<Candidate> cOpt = candidateRepository.findById(candidateId);
        if (cOpt.isEmpty()) throw new RuntimeException("Candidate not found");
        Candidate c = cOpt.get();
        String msg = "You have been selected for an interview";
        // Simulate sending (could be replaced with actual email/SMS)
        Notification n = new Notification(c.getEmail(), msg, LocalDateTime.now());
        return notificationRepository.save(n);
    }

    public Notification sendSelectionMessageDirect(String recipient, String method) {
        // method can be "email" or "sms" (simulated). We'll treat recipient string as email/phone.
        String msg = "You have been selected for an interview";
        Notification n = new Notification(recipient, msg, LocalDateTime.now());
        return notificationRepository.save(n);
    }

    public List<Notification> getAll() {
        return notificationRepository.findAll();
    }
}
