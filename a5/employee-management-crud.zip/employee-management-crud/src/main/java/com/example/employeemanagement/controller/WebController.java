package com.example.employeemanagement.controller;

import com.example.employeemanagement.model.Employee;
import com.example.employeemanagement.model.Department;
import com.example.employeemanagement.service.EmployeeService;
import com.example.employeemanagement.service.DepartmentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class WebController {
    private final EmployeeService employeeService;
    private final DepartmentService departmentService;

    public WebController(EmployeeService employeeService, DepartmentService departmentService) {
        this.employeeService = employeeService;
        this.departmentService = departmentService;
    }

    // Employees page
    @GetMapping({"/employees", "/"})
    public String employees(@RequestParam(required = false) Long departmentId, Model model) {
        model.addAttribute("departments", departmentService.getAll());
        if (departmentId != null) {
            model.addAttribute("employees", employeeService.getEmployeesByDepartment(departmentId));
        } else {
            model.addAttribute("employees", employeeService.getAllEmployees());
        }
        return "employees";
    }

    @GetMapping("/employees/new")
    public String newEmployeeForm(Model model) {
        model.addAttribute("employee", new Employee());
        model.addAttribute("departments", departmentService.getAll());
        return "employee_form";
    }

    @PostMapping("/employees/save")
    public String saveEmployee(@ModelAttribute Employee employee, RedirectAttributes ra) {
        // If department has id, fetch managed entity
        if (employee.getDepartment() != null && employee.getDepartment().getId() != null) {
            Department d = departmentService.getById(employee.getDepartment().getId()).orElse(null);
            employee.setDepartment(d);
        }
        employeeService.save(employee);
        ra.addFlashAttribute("success", "Employee saved");
        return "redirect:/employees";
    }

    @GetMapping("/employees/edit/{id}")
    public String editEmployee(@PathVariable Long id, Model model, RedirectAttributes ra) {
        var empOpt = employeeService.getById(id);
        if (empOpt.isEmpty()) {
            ra.addFlashAttribute("error", "Employee not found");
            return "redirect:/employees";
        }
        model.addAttribute("employee", empOpt.get());
        model.addAttribute("departments", departmentService.getAll());
        return "employee_form";
    }

    @GetMapping("/employees/delete/{id}")
    public String deleteEmployee(@PathVariable Long id, RedirectAttributes ra) {
        employeeService.delete(id);
        ra.addFlashAttribute("success", "Employee deleted");
        return "redirect:/employees";
    }

    // Departments page
    @GetMapping("/departments")
    public String departments(Model model) {
        model.addAttribute("departments", departmentService.getAll());
        return "departments";
    }

    @GetMapping("/departments/new")
    public String newDepartmentForm(Model model) {
        model.addAttribute("department", new Department());
        return "department_form";
    }

    @PostMapping("/departments/save")
    public String saveDepartment(@ModelAttribute Department department, RedirectAttributes ra) {
        departmentService.save(department);
        ra.addFlashAttribute("success", "Department saved");
        return "redirect:/departments";
    }

    @GetMapping("/departments/edit/{id}")
    public String editDepartment(@PathVariable Long id, Model model, RedirectAttributes ra) {
        var opt = departmentService.getById(id);
        if (opt.isEmpty()) {
            ra.addFlashAttribute("error", "Department not found");
            return "redirect:/departments";
        }
        model.addAttribute("department", opt.get());
        return "department_form";
    }

    @GetMapping("/departments/delete/{id}")
    public String deleteDepartment(@PathVariable Long id, RedirectAttributes ra) {
        departmentService.delete(id);
        ra.addFlashAttribute("success", "Department deleted");
        return "redirect:/departments";
    }
}
