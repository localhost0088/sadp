package com.example.employeemanagement.controller;

import com.example.employeemanagement.model.Employee;
import com.example.employeemanagement.model.Department;
import com.example.employeemanagement.service.EmployeeService;
import com.example.employeemanagement.service.DepartmentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    private final EmployeeService service;
    private final DepartmentService departmentService;

    public EmployeeController(EmployeeService service, DepartmentService departmentService) {
        this.service = service;
        this.departmentService = departmentService;
    }

    @GetMapping
    public List<Employee> getAll() {
        return service.getAllEmployees();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getById(@PathVariable Long id) {
        return service.getById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/department/{deptId}")
    public List<Employee> getByDepartment(@PathVariable Long deptId) {
        return service.getEmployeesByDepartment(deptId);
    }

    @PostMapping
    public ResponseEntity<Employee> create(@RequestBody Employee employee) {
        // if department provided with id, ensure it's managed
        if (employee.getDepartment() != null && employee.getDepartment().getId() != null) {
            Department d = departmentService.getById(employee.getDepartment().getId()).orElse(null);
            employee.setDepartment(d);
        }
        return ResponseEntity.ok(service.save(employee));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Employee> update(@PathVariable Long id, @RequestBody Employee employee) {
        return service.getById(id).map(existing -> {
            existing.setName(employee.getName());
            existing.setEmail(employee.getEmail());
            existing.setPosition(employee.getPosition());
            if (employee.getDepartment() != null && employee.getDepartment().getId() != null) {
                Department d = departmentService.getById(employee.getDepartment().getId()).orElse(null);
                existing.setDepartment(d);
            } else {
                existing.setDepartment(null);
            }
            service.save(existing);
            return ResponseEntity.ok(existing);
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
