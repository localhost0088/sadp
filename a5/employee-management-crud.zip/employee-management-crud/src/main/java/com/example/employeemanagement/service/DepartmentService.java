package com.example.employeemanagement.service;

import com.example.employeemanagement.model.Department;
import com.example.employeemanagement.repository.DepartmentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService {
    private final DepartmentRepository repository;

    public DepartmentService(DepartmentRepository repository) {
        this.repository = repository;
    }

    public List<Department> getAll() {
        return repository.findAll();
    }

    public Optional<Department> getById(Long id) {
        return repository.findById(id);
    }

    public Department save(Department dept) {
        return repository.save(dept);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
