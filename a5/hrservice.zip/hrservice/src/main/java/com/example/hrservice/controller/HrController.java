package com.example.hrservice.controller;

import com.example.hrservice.service.MessageService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/hr")
public class HrController {
    private final MessageService messageService;

    public HrController(MessageService messageService) {
        this.messageService = messageService;
    }

    @PostMapping("/notify")
    public ResponseEntity<String> notifyCandidate(@RequestParam String candidateName) {
        String message = messageService.sendInterviewMessage(candidateName);
        return ResponseEntity.ok(message);
    }
}
