package com.example.hrservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrserviceApplication.class, args);
	}
//http://localhost:8080/hr/notify?candidateName=John%20Doe
}
