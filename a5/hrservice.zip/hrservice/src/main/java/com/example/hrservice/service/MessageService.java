package com.example.hrservice.service;

import org.springframework.stereotype.Service;

@Service
public class MessageService {
    public String sendInterviewMessage(String candidateName) {
        return "Dear " + candidateName + ", You have been selected for an interview.";
    }
}
