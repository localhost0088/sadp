package com.example.hrservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
