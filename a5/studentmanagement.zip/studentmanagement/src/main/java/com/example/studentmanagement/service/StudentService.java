package com.example.studentmanagement.service;

import com.example.studentmanagement.entity.Student;
import com.example.studentmanagement.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    public List<Student> list() {
        return repository.findAll();
    }

    public Optional<Student> get(Long id) {
        return repository.findById(id);
    }

    public Student create(Student student) {
        return repository.save(student);
    }

    public Student update(Long id, Student updated) {
        return repository.findById(id)
            .map(student -> {
                student.setName(updated.getName());
                student.setEmail(updated.getEmail());
                student.setCourse(updated.getCourse());
                student.setEnrollmentDate(updated.getEnrollmentDate());
                return repository.save(student);
            }).orElse(null);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
