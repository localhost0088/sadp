package com.example.studentmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentmanagementApplication.class, args);
	}

}


// {
        
//         "name": "kumar",
//         "email": "ks@example.com",
//         "course": "art",
//         "enrollmentDate": "2025-01-02"
//     }

    